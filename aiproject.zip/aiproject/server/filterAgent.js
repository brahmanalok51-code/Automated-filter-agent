

function dedupe(data, keyCols = []) {
const seen = new Set();
const out = [];
for (const r of data) {
const key = keyCols.length ? keyCols.map(c=>r[c]).join('||') : JSON.stringify(r);
if (!seen.has(key)) { seen.add(key); out.push(r); }
}
return out;
}


function removeOutliersIQR(data, numericCol) {
const values = data.map(r => Number(r[numericCol])).filter(v => !Number.isNaN(v)).sort((a,b)=>a-b);
if (values.length < 4) return data;
const q1 = values[Math.floor((values.length-1)*0.25)];
const q3 = values[Math.floor((values.length-1)*0.75)];
const iqr = q3 - q1;
const low = q1 - 1.5*iqr;
const high = q3 + 1.5*iqr;
return data.filter(r => {
const v = Number(r[numericCol]);
if (Number.isNaN(v)) return true; // keep non-numeric
return v >= low && v <= high;
});
}


async function runAgent({ data, filters = [], automate = {} }) {
// 1) Validate
const input = Array.isArray(data) ? data.slice() : [];


// 2) Automated pre-processing
let processed = input;
if (automate.dedupe) processed = dedupe(processed, automate.dedupeOn || []);


// 3) Automated outlier removal (if configured for a numeric column)
if (automate.outlier && automate.outlier.enabled && automate.outlier.column) {
processed = removeOutliersIQR(processed, automate.outlier.column);
}


// 4) Apply filters
const filtered = processed.filter(r => {
if (!filters || filters.length === 0) return true;
// All filters combined with AND; you can change to OR or build groups
return filters.every(f => applyFilter(r, f));
});


// 5) Post-process: small examples (e.g., truncate long text, normalize fields)
const truncated = filtered.map(r => {
const copy = { ...r };
for (const k in copy) {
if (typeof copy[k] === 'string' && copy[k].length > 200) copy[k] = copy[k].slice(0, 197) + '...';
}
return copy;
});


return { count: truncated.length, rows: truncated };
}


module.exports = { runAgent };