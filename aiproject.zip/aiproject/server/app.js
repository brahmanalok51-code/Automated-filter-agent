// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { runAgent } = require('./filterAgent');


const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));


// Health
app.get('/health', (req, res) => res.json({ ok: true }));


// POST /filter
// body: { data: [ {col: val, ...}, ... ], filters: [ {col, op, value} ], automate: { dedupe:true, outlier: {enabled:true, method:'iqr'} } }
app.post('/filter', async (req, res) => {
try {
const { data, filters = [], automate = {} } = req.body;
if (!Array.isArray(data)) return res.status(400).json({ error: 'data must be an array' });


const result = await runAgent({ data, filters, automate });
res.json(result);
} catch (err) {
console.error(err);
res.status(500).json({ error: err.message });
}
});


const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));