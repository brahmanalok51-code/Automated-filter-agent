import { useState } from "react";
import { motion } from "framer-motion";

function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length === 0) return [];
  const headers = lines[0].split(",").map((h) => h.trim());
  return lines.slice(1).map((l) => {
    const vals = l.split(",");
    const obj = {};
    headers.forEach((h, i) => (obj[h] = vals[i] ?? ""));
    return obj;
  });
}

export default function App() {
  const [raw, setRaw] = useState("");
  const [data, setData] = useState([]);
  const [filters, setFilters] = useState([]);
  const [automate, setAutomate] = useState({
    dedupe: false,
    outlier: { enabled: false, column: "" },
  });
  const [result, setResult] = useState(null);

  function loadData() {
    try {
      const j = JSON.parse(raw);
      if (Array.isArray(j)) {
        setData(j);
        return;
      }
    } catch (e) {}

    try {
      const parsed = parseCSV(raw);
      setData(parsed);
    } catch (e) {
      alert("Invalid input");
    }
  }

  function addFilter() {
    setFilters((prev) => [...prev, { col: "", op: "eq", value: "" }]);
  }

  function updateFilter(i, key, val) {
    setFilters((prev) =>
      prev.map((f, idx) => (idx === i ? { ...f, [key]: val } : f))
    );
  }

  function run() {
    fetch("http://localhost:4000/filter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ data, filters, automate }),
    })
      .then((r) => r.json())
      .then(setResult)
      .catch((e) => alert(e.message));
  }

  return (
    <div className="p-10 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 min-h-screen text-white">
      <motion.h2
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-4xl font-extrabold text-center drop-shadow-xl"
      >
        Automated Data Filter Agent
      </motion.h2>

      {/* Input Section */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mt-10 bg-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-2xl border border-white/20"
      >
        <label className="font-semibold text-lg">Input Data</label>
        <textarea
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          rows={8}
          className="w-full p-4 mt-3 bg-white/20 border border-white/30 text-white rounded-lg outline-none focus:ring-2 focus:ring-yellow-300"
          placeholder="Paste CSV or JSON here..."
        />

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.92 }}
          onClick={loadData}
          className="mt-4 bg-yellow-400 text-black px-5 py-2 font-semibold rounded-lg shadow-lg hover:bg-yellow-300 transition"
        >
          Load Data
        </motion.button>
      </motion.div>

      {/* Data Preview */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="mt-6 bg-white/10 backdrop-blur-xl p-6 rounded-2xl border border-white/20 shadow-xl"
      >
        <h3 className="text-xl font-semibold mb-3">Data Preview ({data.length} rows)</h3>
        <div className="max-h-64 overflow-auto bg-black/20 p-4 rounded-lg text-sm">
          <pre>{JSON.stringify(data.slice(0, 20), null, 2)}</pre>
        </div>
      </motion.div>

      {/* Filters Section */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="mt-6 bg-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-white/20"
      >
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-semibold">Filters</h3>

          <motion.button
            whileTap={{ scale: 0.9 }}
            className="bg-green-400 px-4 py-2 text-black font-semibold rounded-lg shadow hover:bg-green-300"
            onClick={addFilter}
          >
            + Add Filter
          </motion.button>
        </div>

        <div className="mt-4 space-y-4">
          {filters.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex gap-4"
            >
              <input
                placeholder="column"
                value={f.col}
                onChange={(e) => updateFilter(i, "col", e.target.value)}
                className="flex-1 p-2 bg-white/20 border border-white/30 rounded-lg text-white"
              />

              <select
                value={f.op}
                onChange={(e) => updateFilter(i, "op", e.target.value)}
                className="p-2 bg-white/20 border border-white/30 rounded-lg text-white"
              >
                <option value="eq">=</option>
                <option value="ne">!=</option>
                <option value="contains">contains</option>
                <option value="gt">&gt;</option>
                <option value="lt">&lt;</option>
                <option value="gte">≥</option>
                <option value="lte">≤</option>
              </select>

              <input
                placeholder="value"
                value={f.value}
                onChange={(e) => updateFilter(i, "value", e.target.value)}
                className="flex-1 p-2 bg-white/20 border border-white/30 rounded-lg text-white"
              />
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Automation */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="mt-6 bg-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-white/20"
      >
        <h3 className="text-xl font-semibold mb-4">Automation</h3>

        <label className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={automate.dedupe}
            onChange={(e) =>
              setAutomate((prev) => ({ ...prev, dedupe: e.target.checked }))
            }
          />
          <span>Dedupe</span>
        </label>

        <div className="mt-3">
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={automate.outlier.enabled}
              onChange={(e) =>
                setAutomate((prev) => ({
                  ...prev,
                  outlier: { ...prev.outlier, enabled: e.target.checked },
                }))
              }
            />
            <span>Remove Outliers (IQR)</span>
          </label>

          <input
            placeholder="numeric column"
            value={automate.outlier.column}
            onChange={(e) =>
              setAutomate((prev) => ({
                ...prev,
                outlier: { ...prev.outlier, column: e.target.value },
              }))
            }
            className="mt-3 w-full p-3 bg-white/20 border border-white/30 rounded-lg text-white"
          />
        </div>
      </motion.div>

      {/* Run Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.9 }}
        onClick={run}
        className="w-full mt-8 bg-pink-400 py-3 rounded-xl text-black text-lg font-semibold shadow-xl hover:bg-pink-300"
      >
        Run Agent
      </motion.button>

      {/* Result */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mt-8 bg-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-xl border border-white/20"
      >
        <h3 className="text-xl font-semibold mb-3">Result</h3>
        {result ? (
          <div>
            <div className="text-white/90 font-medium mb-3">
              Count: {result.count}
            </div>
            <pre className="max-h-64 overflow-auto bg-black/20 p-4 rounded-lg text-sm">
              {JSON.stringify(result.rows.slice(0, 50), null, 2)}
            </pre>
          </div>
        ) : (
          <div className="text-white/70">No result yet</div>
        )}
      </motion.div>
    </div>
  );
}
